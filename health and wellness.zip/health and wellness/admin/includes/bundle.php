<link rel="stylesheet" href="../includes/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<link rel="stylesheet" href="../includes/css/style.css">
<link rel="stylesheet" href="./includes/style.css">

<script src="../includes/js/jquery-3.7.1.slim.min.js"></script>
<script src="../includes/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/1c7d0640ce.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>