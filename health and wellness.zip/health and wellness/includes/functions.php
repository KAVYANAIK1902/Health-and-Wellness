<?php

if (isset($_POST['add_cart'])) {
    if (!isset($_SESSION['uid'])) {
        echo "<script>alert('Please login or register to add to cart.');</script>";
    } else {
        $uid = $_SESSION['uid'];
        $pid = $_POST['pid'];
        $qty = $_POST['qty'];

        $sql = "SELECT * from cart where product_id = '$pid' and user_id = '$uid'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<script>alert('Product is already in cart.');</script>";
        } else {
            $sql = "INSERT into cart (user_id,product_id,quantity) values('$uid','$pid','$qty')";
            $result = $conn->query($sql);
            if ($result) {
                echo "<script>alert('Product added to cart.');</script>";
            } else {
                echo "<script>alert('Product couldn't be added to cart.');</script>";
            }
        }
    }
}

if (isset($_POST['add_wishlist'])) {
    if (!isset($_SESSION['uid'])) {
        echo "<script>alert('Please login or register to add to cart.');</script>";
    } else {
        $uid = $_SESSION['uid'];
        $pid = $_POST['pid'];

        $sql = "SELECT * from wishlist where product_id = '$pid' and user_id = '$uid'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<script>alert('Product is already in wishlist.');</script>";
        } else {
            $sql = "INSERT into wishlist (user_id,product_id) values('$uid','$pid')";
            $result = $conn->query($sql);
            if ($result) {
                echo "<script>alert('Product added to Favourites.');</script>";
            } else {
                echo "<script>alert('Product couldn't be added to Favourites.');</script>";
            }
        }
    }
}

if (isset($_POST['place_order'])) {
    if (!isset($_SESSION['uid'])) {
        echo "<script>alert('Please login or register to add to cart.');</script>";
    } else {
    }
}
