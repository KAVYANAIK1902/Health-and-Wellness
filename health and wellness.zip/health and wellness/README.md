--------------HRMS Project----------------------
How to run the program.

# install xampp server if not installed.

# open "htdocs" folder in xampp server installed folder.

# Unzip the file and place "HRMS" folder inside "htdocs".

# start the apache,mysql servers in xampp.

# navigate to the project by opening the browser and enter address "localhost/ #folder_name# /".

# Example : if the folder name is "health and wellness" the address will be "localhost/health and wellness/".

# Note: check database manual before running the project otherwise it may give you errors.

------------Default Users added by project creator----------

------------users/employee credentials-----------------

username : test
email : test@gmail.com
password : test

--------Admin credentials-----------------

adminName : vikram
email : vikram@gmail.com
password : vikram


----------------Informations and Notes -------------------------------

# /includes contains configuration file any changes for database connection should be made there.

# /DATABASE cointains the database file. Read database README.md file for more information.
