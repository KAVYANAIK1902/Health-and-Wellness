<?php
include './includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About us</title>
</head>

<body>
    <?php include './includes/header.php' ?>
    <?php include './includes/nav.php' ?>

    <div class="container mt-5">
        <div class="card mb-3">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="./includes/img/about.jpg" class="img-fluid rounded-start" alt="image">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">About Us</h5>
                        <p class="card-text fw-bold">
                            Welcome to [Your Company Name], your number one source for all things health and wellness. We're dedicated to giving you the very best of health products, with a focus on quality, customer service, and uniqueness. Founded in [Year] by [Founder's Name], [Your Company Name] has come a long way from its beginnings in a [starting location, e.g., home office, small shop]. When [Founder's Name] first started out, their passion for helping others through holistic health solutions drove them to do intense research, quit their day job, and turn hard work and inspiration into a booming online store. We now serve customers all over the world and are thrilled to be a part of the eco-friendly, fair trade wing of the health and wellness industry.
                        </p>
                        <p class="card-text">
                            At [Your Company Name], we believe in the power of nature and science working together to provide the best solutions for your health needs. Our products are carefully selected and tested to ensure they meet our high standards of quality and effectiveness. Whether you're looking for vitamins, supplements, herbal remedies, or fitness equipment, we have something for everyone. Our team is committed to finding innovative and effective products that can help you live a healthier and more balanced life.
                            We pride ourselves on our customer service and are always here to help. If you have any questions about our products, need advice on which product is right for you, or simply want to chat about health and wellness, our friendly and knowledgeable team is always ready to assist. We believe that our customers are the heart of our business, and we strive to build long-lasting relationships based on trust and satisfaction.
                            We are also deeply committed to sustainability and giving back to the community. We source our products from suppliers who practice ethical and sustainable methods, ensuring that what you buy is not only good for you but also good for the planet. Additionally, a portion of our profits goes towards supporting various health and wellness initiatives around the world. We believe in making a positive impact and are proud to contribute to a healthier and happier world.
                            Thank you for taking the time to learn more about us. We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us. We're always happy to hear from our customers and look forward to serving you. Thank you for choosing [Your Company Name] as your trusted partner in health and wellness. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include './includes/footer.php' ?>
    <?php include './includes/bundle.php' ?>
</body>

</html>