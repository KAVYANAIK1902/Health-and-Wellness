# -----------------HRMS project----------------

# Instruction to use database

# Install xampp server and open phpMyAdmin page by navigating in browser to localhost/phpMyAdmin/

# Create a new database with name "ecommerce_health".

# Drag and drop the sql file to the database "ecommerce_health" OR use import in "ecommerce_health" select sql file in current folder and import everything.

# if you name the database to something else change connection configuration in /includes/config.php file
